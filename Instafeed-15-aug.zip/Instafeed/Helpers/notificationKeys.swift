//
//  notificationKeys.swift
//  Instafeed
//
//  Created by gulam ali on 08/08/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import Foundation

struct NotificationKeys {
    static let ticktapped = "ticktapped"
    static let profileinfo = "profileinfo"
}
