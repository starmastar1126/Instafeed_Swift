//
//  Loader.swift
//  Instafeed
//
//  Created by gulam ali on 22/07/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

//import Foundation
//import ProgressHUD
//
//class Loader:NSObject{
//    
//    class func showLoader(){
//        ProgressHUD.sh
//    }
//    
//}
