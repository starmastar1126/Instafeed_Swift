//
//  categorycell.swift
//  Instafeed
//
//  Created by gulam ali on 09/07/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import UIKit
import Foundation

class categorycell: UICollectionViewCell {
    
    
    @IBOutlet weak var bg_img: UIImageView!
    
    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var subtitle: UILabel!
    
    
    
    
}
