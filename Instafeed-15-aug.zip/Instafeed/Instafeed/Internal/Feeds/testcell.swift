//
//  testcell.swift
//  Instafeed
//
//  Created by gulam ali on 23/07/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import UIKit

class testcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
