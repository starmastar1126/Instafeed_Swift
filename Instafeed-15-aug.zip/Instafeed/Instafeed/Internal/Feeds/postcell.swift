//
//  postcell.swift
//  Instafeed
//
//  Created by gulam ali on 06/08/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import UIKit

class postcell: UICollectionViewCell {
    
    
    @IBOutlet weak var postimage: UIImageView!
    
}
