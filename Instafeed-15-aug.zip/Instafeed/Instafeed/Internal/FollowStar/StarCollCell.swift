//
//  StarCollCell.swift
//  Instafeed
//
//  Created by gulam ali on 10/07/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import UIKit

class StarCollCell: UICollectionViewCell {
    
    @IBOutlet weak var myview: UIView!
    
}
