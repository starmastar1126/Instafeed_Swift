//
//  Page.swift
//  audible
//
//  Created by Brian Voong on 9/2/16.
//  Copyright © 2016 Lets Build That App. All rights reserved.
//

import Foundation

struct Page {
    let title: String
    let message: String
    let imageName: String
}
