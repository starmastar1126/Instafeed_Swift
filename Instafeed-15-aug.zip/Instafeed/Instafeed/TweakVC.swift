//
//  TweakVC.swift
//  Instafeed
//
//  Created by gulam ali on 22/07/19.
//  Copyright © 2019 gulam ali. All rights reserved.
//

import UIKit

class TweakVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        let move = storyboard?.instantiateViewController(withIdentifier: "Mainpagevc") as! Mainpagevc
//        present(move, animated: false, completion: nil)
//    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
